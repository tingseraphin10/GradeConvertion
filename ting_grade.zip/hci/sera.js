function compute() {
    var name = document.getElementById('name').value;
    var studentNumber = document.getElementById('studentNumber').value;
    var mid = document.getElementById('midterm').value;
    var fin = document.getElementById('final').value;

    if (!name || !studentNumber || !mid || !fin) {
      alert("Please fill in all fields.");
      return;
    }

    var avg = (parseFloat(mid) + parseFloat(fin)) / 2;
    var remarks;

    if (avg >= 99) {
      remarks = "1.0";
    } else if (avg >= 97) {
      remarks = "1.1";
    } else if (avg >= 95) {
      remarks = "1.2";
    } else if (avg >= 93) {
      remarks = "1.3";
    } else if (avg >= 90) {
      remarks = "1.5";
    } else if (avg >= 89) {
      remarks = "1.6";
    } else if (avg >= 87) {
      remarks = "1.8";
    } else if (avg >= 86) {
      remarks = "1.9";
    } else if (avg >= 85) {
      remarks = "2.0";
    } else if (avg >= 84) {
      remarks = "2.1";
    } else if (avg >= 83) {
      remarks = "2.2";
    } else if (avg >= 82) {
      remarks = "2.3";
    } else if (avg >= 81) {
      remarks = "2.4";
    } else if (avg >= 80) {
      remarks = "2.5";
    } else if (avg >= 79) {
      remarks = "2.6";
    } else if (avg >= 78) {
      remarks = "2.7";
    } else if (avg >= 77) {
      remarks = "2.8";
    } else if (avg >= 76) {
      remarks = "2.9";
    } else if (avg >= 75) {
      remarks = "3.0";
    } else {
      remarks = "5.0";
    }

    document.getElementById('finalGradeOutput').innerHTML = avg.toFixed(2);
    document.getElementById('remarksOutput').innerHTML = remarks;
  }

  function reset() {
    document.getElementById('name').value = '';
    document.getElementById('studentNumber').value = '';
    document.getElementById('midterm').value = '';
    document.getElementById('final').value = '';
    document.getElementById('finalGradeOutput').innerHTML = '--';
    document.getElementById('remarksOutput').innerHTML = '--';
  }